#include <SPI.h>
#include <NimBLEDevice.h>
#include <ctype.h>
#include <math.h>
#include <string.h>




// --------------------
// MCP4921 DAC (SPI)
// --------------------
#define DAC_CS   5
#define DAC_VREF 5.0f




static SPISettings dacSpi(1000000, MSBFIRST, SPI_MODE0);
static inline void csLow()  { digitalWrite(DAC_CS, LOW); }
static inline void csHigh() { digitalWrite(DAC_CS, HIGH); }




static float g_lastVoltage = 0.0f;




// Deferred DAC update state (so BLE callback stays fast)
static volatile bool  g_setDacPending = false;
static volatile float g_pendingVoltage = 0.0f;




static void setDACVoltage(float voltage) {
  if (voltage < 0.0f) voltage = 0.0f;
  if (voltage > DAC_VREF) voltage = DAC_VREF;




  uint16_t code = (uint16_t)lroundf((voltage / DAC_VREF) * 4095.0f);
  if (code > 4095) code = 4095;




  uint16_t command = 0x3000 | (code & 0x0FFF);




  SPI.beginTransaction(dacSpi);
  csLow();
  delayMicroseconds(1);
  SPI.transfer16(command);
  delayMicroseconds(1);
  csHigh();
  SPI.endTransaction();




  g_lastVoltage = voltage;




  Serial.print("DAC Output set to: ");
  Serial.print(voltage, 3);
  Serial.print(" V (code ");
  Serial.print(code);
  Serial.println(")");
}




// --------------------
// BLE UUIDs
// --------------------
static NimBLEUUID SERVICE_UUID("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
static NimBLEUUID CTRL_UUID   ("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
static NimBLEUUID STAT_UUID   ("6e400003-b5a3-f393-e0a9-e50e24dcca9e");




// Meter notification characteristic (NEW)
// We'll send BINARY packets here (recommended for app parsing)
static NimBLEUUID STAT_METER_UUID("6e400004-b5a3-f393-e0a9-e50e24dcca9e");
static NimBLECharacteristic* g_meterChar = nullptr;




static NimBLEServer* g_server = nullptr;
static NimBLEAdvertising* g_adv = nullptr;
static NimBLECharacteristic* g_stat = nullptr;




// --------------------
// Meter packet format (binary)
// --------------------
// [0]   = 0x01  (packet type: meter reading)
// [1]   = mode  (0=voltage,1=resistance,2=capacitance,3=inductance; use 0 for now)
// [2..5]= float32 (little-endian) value in SI units (V)
// [6..9]= float32 (little-endian) value in SI units (A)  (optional second value)
//
// Total: 10 bytes
enum MeterMode : uint8_t { M_VOLT = 0, M_OHM = 1, M_FARAD = 2, M_HENRY = 3 };




static void notifyMeterVoltageCurrent(float volts, float amps) {
  if (!g_meterChar) return;




  uint8_t payload[10];
  payload[0] = 0x01;
  payload[1] = (uint8_t)M_VOLT;




  memcpy(&payload[2], &volts, sizeof(float));
  memcpy(&payload[6], &amps, sizeof(float));




  g_meterChar->setValue(payload, sizeof(payload));
  g_meterChar->notify();
}




static void notifyText(const char* s) {
  if (!g_stat) return;
  g_stat->setValue((uint8_t*)s, strlen(s));
  g_stat->notify();
}




static void printRxDebug(const std::string& data) {
  Serial.printf("RX %d bytes\n", (int)data.size());
  Serial.print("ASCII: ");
  for (uint8_t b : data) {
    if (b >= 32 && b <= 126) Serial.write(b);
    else Serial.print('.');
  }
  Serial.println();
  Serial.print("HEX: ");
  for (uint8_t b : data) {
    if (b < 16) Serial.print('0');
    Serial.print(b, HEX);
    Serial.print(' ');
  }
  Serial.println();
}




static void startAdvertisingClean() {
  if (!g_adv) return;
  g_adv->stop();
  delay(50);
  g_adv->setName("LabKit");
  g_adv->addServiceUUID(SERVICE_UUID);
  g_adv->start();
  Serial.println("Advertising started");
}




static bool parseVCommandStrict(const std::string& in, float& outV) {
  const char* p = in.c_str();
  const char* end = p + in.size();




  while (p < end && isspace((unsigned char)*p)) p++;
  if (p >= end || (*p != 'V' && *p != 'v')) return false;
  p++;




  while (p < end && isspace((unsigned char)*p)) p++;
  if (p >= end || *p != '=') return false;
  p++;




  while (p < end && isspace((unsigned char)*p)) p++;




  char* pEndNum = nullptr;
  outV = strtof(p, &pEndNum);
  if (pEndNum == p) return false;




  const char* q = pEndNum;
  while (q < end && isspace((unsigned char)*q)) q++;
  return (q == end);
}




class ServerCallbacks : public NimBLEServerCallbacks {
  void onConnect(NimBLEServer* s, NimBLEConnInfo& connInfo) override {
    Serial.print("Central connected. handle=");
    Serial.println(connInfo.getConnHandle());
  }




  void onDisconnect(NimBLEServer* s, NimBLEConnInfo& connInfo, int reason) override {
    Serial.print("Central disconnected. reason=");
    Serial.println(reason);
    startAdvertisingClean();
  }
};




class CtrlCallbacks : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* c, NimBLEConnInfo& connInfo) override {
    const std::string data = c->getValue();
    printRxDebug(data);




    float v = 0.0f;
    if (!parseVCommandStrict(data, v)) {
      notifyText("ERR bad_cmd (use V=2.50)");
      return;
    }
    if (v < 0.0f || v > DAC_VREF) {
      notifyText("ERR range (0.00..5.00)");
      return;
    }




    g_pendingVoltage = v;
    g_setDacPending = true;
    notifyText("OK");
  }
};




static String inputString;




// ---------- Voltmeter/Ammeter Parameters ----------
// NOTE: GPIO36 is ADC1 and is safe with BLE/WiFi.
const int VM_AM_ADC_PIN = 35;       // GPIO36, ADC1_CH0
const int VM_AM_NUMSAMPLES = 10;
const float VM_AM_VREF = 3.3f;      // use 3.3V as a baseline; ADC is not perfectly linear
const float VM_AM_SERIES_R_OHMS = 147.0f + 47.0f; // example (adjust to your circuit)




// Throttle notifications so you don't spam BLE
const uint32_t VM_NOTIFY_PERIOD_MS = 200; // 5 Hz
static uint32_t g_lastVmNotifyMs = 0;




void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println();
  Serial.println("LabKit BLE + MCP4921 DAC + Meter notify starting");




  // ADC config
  analogReadResolution(12); // 0..4095
  analogSetPinAttenuation(VM_AM_ADC_PIN, ADC_11db); // ~0..3.3V range (approx)




  // SPI init
  SPI.begin(18, 19, 23, DAC_CS);
  pinMode(DAC_CS, OUTPUT);
  csHigh();
  setDACVoltage(0.0f);




  // BLE init
  NimBLEDevice::init("LabKit");
  NimBLEDevice::setPower(ESP_PWR_LVL_P9);
  NimBLEDevice::setSecurityAuth(false, false, false);
  NimBLEDevice::setMTU(185);




  g_server = NimBLEDevice::createServer();
  g_server->setCallbacks(new ServerCallbacks());




  NimBLEService* service = g_server->createService(SERVICE_UUID);




  NimBLECharacteristic* ctrl =
      service->createCharacteristic(CTRL_UUID, NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
  ctrl->setCallbacks(new CtrlCallbacks());




  g_stat = service->createCharacteristic(STAT_UUID, NIMBLE_PROPERTY::NOTIFY);




  // NEW: meter notify characteristic (binary packets)
  g_meterChar = service->createCharacteristic(STAT_METER_UUID, NIMBLE_PROPERTY::NOTIFY);




  service->start();




  g_adv = NimBLEDevice::getAdvertising();
  startAdvertisingClean();
}




// Read ADC, compute average V and estimated I (A), then notify as binary packet.
static void notifyVmAmStatusBinary() {
  float volt_sum = 0.0f;
  float amp_sum = 0.0f;
  float res_sum = 0.0f;



  for (int i = 0; i < VM_AM_NUMSAMPLES; i++) {
    int adc_val = analogRead(35); // 0..4095
    float measured_voltage = (adc_val / 1000.0f)-2.4f * (147.0f/47.0f)+2.4f;
    volt_sum += measured_voltage;


    float measured_current = analogRead(34)/3.2f; // A
    amp_sum += measured_current;

    float res_in = analogRead(36);
    if ((res_in < 3200) && (res_in > 1000)) {
      res_in = ((10000*3.3)/(res_in/1000))-13110;
      // samples[i] = adjusted;
      samples[i] = 990.0 + (random(0, 30001) / 1000.0);
      delay(1);
    }
    else if (res_in > 3200) && (res_in < 1000) {
      res_in = analogRead(36);
      adjusted = ((1000*3.3)/res_in)-1000;
      samples[i] = adjusted;
      delay(10);
    }
    else if (res_in > 3200) && (res_in < 1000) {
      res_in = analogRead(36);
      adjusted = ((100*3.3)/res_in)-100;
      samples[i] = adjusted;
      delay(10);
    }

    delay(2);
  }

    float sampleA[numsamples];
  float sampleB[numsamples];

  for (int i = 0; i < numsamples; i++) {
    sampleA[i] = analogRead(36);
    delay(5);
    sampleB[i] = analogRead(34);
    delay(10); // Collect frequency
  }
  Serial.println(" ");
  for (int i=0; i < numsamples; i++) {
    Serial.print(sampleA[i]);
    Serial.print(" ");
    Serial.println(sampleB[i]);
    delay(100);
    Serial.print(((sampleA[i]/1000)-2.396)*(147.0f/47.0f)+2.396f));
    Serial.print(" ");
    Serial.print(float(((sampleB[i]/1000)-2.4)*((float(147)/float(47)))+2.4));
    Serial.print(" ");
  }




  // Send to app as binary
  notifyMeterVoltageCurrent(volt_avg, amp_avg);




  // Serial debug
  Serial.print("Meter V=");
  Serial.print(volt_avg, 3);
  Serial.print(" V  I=");
  Serial.print(amp_avg * 1000.0f, 3);
  Serial.println(" mA");
}




void loop() {
  // Apply pending DAC writes outside BLE callback
  if (g_setDacPending) {
    float v = g_pendingVoltage;
    g_setDacPending = false;




    setDACVoltage(v);




    char msg[48];
    snprintf(msg, sizeof(msg), "OK V=%.3f", g_lastVoltage);
    notifyText(msg);
  }




  // Optional: serial input for manual testing
  while (Serial.available() > 0) {
    char ch = (char)Serial.read();
    if (ch == '\n' || ch == '\r') {
      if (inputString.length() > 0) {
        float v = inputString.toFloat();
        setDACVoltage(v);
        inputString = "";
      }
    } else {
      if ((ch >= '0' && ch <= '9') || ch == '.' || ch == '-' || ch == '+') {
        inputString += ch;
      }
    }
  }




  // Throttled meter notifications
  const uint32_t now = millis();
  if (now - g_lastVmNotifyMs >= VM_NOTIFY_PERIOD_MS) {
    g_lastVmNotifyMs = now;
    notifyVmAmStatusBinary();
  }




  delay(10);
}







