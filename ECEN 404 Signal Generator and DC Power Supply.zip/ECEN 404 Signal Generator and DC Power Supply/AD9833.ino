#include <AD9833.h>
#define FSYNC   12    // Chip Select (FSYNC)
#define SCLK    18   // SPI Clock
#define SDATA   23   // SPI MOSI
AD9833 gen(FSYNC, SCLK, SDATA);

void setup() {
  Serial.begin(115200);
  gen.begin();
  delay(100);  // Added delay to stabilize
  gen.setFrequency(100);  // 100 Hz
  Serial.println("AD9833 Initialized");
}

void loop() {
  gen.setWave(AD9833_SINE);
  Serial.println("Sine wave");
  delay(10000);
  gen.setWave(AD9833_TRIANGLE);
  Serial.println("Triangle wave");
  delay(10000);
  gen.setWave(AD9833_SQUARE1);
  Serial.println("Square wave");
  delay(10000);
}