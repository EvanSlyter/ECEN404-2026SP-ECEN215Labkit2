#include <SPI.h>

#define DAC_CS 5             // Chip Select pin

void setup() {
  Serial.begin(115200);
  SPI.begin();                 // SCK=18, MOSI=23 default for ESP32 VSPI
  pinMode(DAC_CS, OUTPUT);
  digitalWrite(DAC_CS, HIGH);

  Serial.println("Type a voltage (0..5) and press enter:");
}

void setDACVoltage(float voltage) {
  if (voltage < 0) voltage = 0;
  if (voltage > 5.0) voltage = 5.0;   // VREF=5.0V
  // MCP4921 is 12-bit (0..4095); At VREF=5.0V:
  uint16_t val = (uint16_t)(voltage * 4095.0 / 5.0 + 0.5); // Round to nearest
  uint16_t command = 0x3000 | (val & 0x0FFF);

  digitalWrite(DAC_CS, LOW);
  SPI.beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0));
  SPI.transfer16(command);
  SPI.endTransaction();
  digitalWrite(DAC_CS, HIGH);

  Serial.print("Output set to: ");
  Serial.print(voltage, 3);
  Serial.println(" V");
}

void loop() {
  static String inputString = "";
  while (Serial.available() > 0) {
    char inChar = Serial.read();
    if (inChar == '\n' || inChar == '\r') {
      if (inputString.length() > 0) {
        float voltage = inputString.toFloat();
        setDACVoltage(voltage);
        inputString = "";
      }
    } else {
      inputString += inChar;
    }
  }
}